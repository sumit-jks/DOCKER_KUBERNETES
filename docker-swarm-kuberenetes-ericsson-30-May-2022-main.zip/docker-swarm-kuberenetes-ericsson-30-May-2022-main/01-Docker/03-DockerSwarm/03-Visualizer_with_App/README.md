   ```
   
   43  ls
   44  vim docker-compose.yaml
   45  docker stack deploy -c docker-compose.yaml visual
   46  docker stack ls
   47  docker stack ps visual
   48  docker service ls

```
