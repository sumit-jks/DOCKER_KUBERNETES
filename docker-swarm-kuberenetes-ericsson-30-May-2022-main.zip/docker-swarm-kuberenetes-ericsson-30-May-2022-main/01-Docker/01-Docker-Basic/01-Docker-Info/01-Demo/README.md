```
    1  ls
    2  git pull 
    3  docker version 
    4  docker run ubuntu echo "hello world"
    5  docker container ls 
    6  docker container ls -a 
    7  docker images 
    8  docker run ubuntu echo "hello world"
    9  docker container ls -a 
   10  docker run busybox  echo "Welcome to the world of docker.!"
   11* docker 
   12  docker container ls 
   13  docker container ls -a 
   14  docker images 
   15  docker container ls -a 
   16  docker run busybox  echo "Welcome to the world of docker....."
   17  history 
   18  ls
   19  cd 01-Docker/
   20  ls
   21  mkdir 01-Docker-Info/01-Demo
   22  mkdir 01-Docker-Info/01-Demo -p 
   23  ls
   24  history > 01-Docker-Info/01-Demo/README.md
   25  vim 01-Docker-Info/01-Demo/README.md
   26  ls
   27  cd ..
   28  ls
   29  cd ..
   30  ls
   31  cd docker-swarm-kuberenetes-ericsson-30-May-2022/
   32  ls
   33  git add . ; git commit -m "01-Docker-Intro" ; git push 
   34  vim /root/.bashrc 
   35  git add . ; git commit -m "01-Docker-Intro" ; git push 
   36  l
   37  git pull
   38  ls
   39  cd 01-Docker/
   40  ls
   41  cd 01-Docker-Info/
   42  ls
   43  cat 01-Demo/README.md 
   44  ls
   45  cd 
   46  docker pull amitvashist7/apache-ex4
   47  docker pull amitvashist7/k8s-tiny-web
   48  docker images 
   49  docker pull amitvashist7/apache-ex4
   50  docker login 
   51  docker pull amitvashist7/apache-ex4
   52  docker logout 
   53  ls
   54  cd docker-swarm-kuberenetes-ericsson-30-May-2022/
   55  ls
   56  cd 01-Docker/
   57  ls
   58  cd 01-Docker-Info/
   59  ls
   60  history 
   61  ls
   62  history > 01-Demo/
   63  history > 01-Demo/README.md 
```
